import React from 'react'

export const MintmeWidget = () => {
  return (
    <div style={{ border: '2px dashed blue', padding: '1rem', borderRadius: '8px' }}>
      <h2>🚀 V3 Mintme Widget</h2>
      <p>Este es el widget en desarrollo.. Ricardox</p>
    </div>
  )
}

